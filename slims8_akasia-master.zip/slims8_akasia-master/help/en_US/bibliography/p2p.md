####P2P Service
<hr>
The basic concept of this feature is to share bibliographical data among Senayan users. This is an XML P2P service utilizing the facilities that already exist in Senayan for sharing catalog data. 

####Cara Penggunaan
<hr>
To use this P2P service, simply click the P2P service, enter a keyword and select the location / url / library intended to search. If the system finds a searchable collection, it will be displayed.

Search on P2P service can use specific Boolean search models. 
> For example ISBN = 0-596-00108-8 AND Title = bazaar. 
>> isbn=0-596-00108-8 AND title=bazaar. 

Besides ISBN and Title, details can also search using Author, GMD and Subject. 
