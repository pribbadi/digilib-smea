#### Item Barcodes Printing
<hr>
The menu provides a means to print barcode-based data items that have been included in SLiMS
