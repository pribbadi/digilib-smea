###Staff Activity

This menu shows the activities of the library staff who have an account in application. The information shown is:
- Username, 
- Login Name, 
- Bibliography Data Entry, 
- Items Data Entry, 
- Member Data Entry, and 
- Circulation. 

So this menu will make visible which staff did what, and how many times.
