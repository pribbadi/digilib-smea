### Statistik Koleksi
<hr>
Berisi informasi total judul koleksi, total item, total item yang sedang dipinjam, total item yang berada di perpustakaan (tidak dipinjam), total judul berdasar GMD, total items berdasar tipe koleksi dan 10 (sepuluh) koleksi paling populer (paling banyak dipinjam). 