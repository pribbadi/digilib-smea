####Master File / Label
<hr>
Gunakan fitur ini untuk memberikan memberikan label keterangan informasi tetang bibliografi. 
Secara default SLIMS mempunyai tiga label: New Title, Favorite Title dan Multimedia.
