####Inventarisasi / Stock Take
<hr>
Modul Stock Take merupakan fasilitas yang ada di SLiMS untuk membantu para pustakawan melakukan kegiatan stock opname. Ketika proses stock opname dimulai, semua koleksi kecuali yang sedang dipinjam (berstatus on loan) akan dianggap hilang, lalu masuk ke dalam menu current lost item sampai koleksi yang bersangkutan di cek pada proses stock take.
