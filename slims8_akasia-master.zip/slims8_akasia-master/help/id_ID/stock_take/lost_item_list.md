### Eksemplar hilang saat ini
<hr>
Isi menu ini merupakan daftar dari koleksi yang dianggap hilang pada saat stock opname selain koleksi yang dipinjam.
