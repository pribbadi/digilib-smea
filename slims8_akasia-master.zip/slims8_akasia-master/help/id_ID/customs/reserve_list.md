####Menu Reserve
<hr>
Menu ini digunakan untuk melakukan pemesanan koleksi/item. Selain itu juga melihat daftar koleksi yang sedang di pesan oleh anggota. 
Informasi yang ada dalam menu ini adalah: 
- Item Code, 
- Title, 
- Member, 
- Reserve Date.

Catatan: koleksi yang dapat dipesan adalah item (eksemplar) yang saat itu tidak ada diperpustakaan (sedang dipinjam), dan tidak dipinjam oleh diri sendiri.
