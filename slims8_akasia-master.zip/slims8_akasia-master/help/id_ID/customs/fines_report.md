#### Laporan denda
<hr>
Merupakan laporan jumlah denda anggota perpustakaan berdasar hari. 