####Pencetakan Label
<hr>
Dengan menu ini kita dapat mencetak label koleksi berdasar data bibliografi yang sudah dimasukkan dalam SLiMS.
Berikut urutan mencetak label menggunakan menu Labels Printing:
- Klik Labels Printing, maka akan muncul tampilan sebagai berikut:
- Pilih bibliografi yang akan dicetak labelnya. Gunakan tombol Shift+klik kotak chek box untuk memilih lebih dari satu secara berurutan dengan cepat. Catatan: sekali cetak maksimal 50 data. Dalam menu label print ini, sudah dimungkinkan untuk mencetak label lebih dari satu, tergantung pada berapa jumlah eksemplar koleksi.
- Klik Add to Print Queue untuk memasukkan pilihan ke dalam antrian cetak.
- Klik Print Selected Data untuk mulai mencetak, maka akan muncul pop-up yang meminta kita untuk mencetak label kedalam printer. 
