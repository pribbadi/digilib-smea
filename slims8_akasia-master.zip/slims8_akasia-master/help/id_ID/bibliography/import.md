####Import Data
<hr>
Menu import data ini digunakan untuk mengambil data bibliografi dari luar SLiMS dalam format csv (atau dari database Senayan yang sudah di eksport dalam bentuk .csv), kemudian dimasukkan dalam program aplikasi Senayan. 
