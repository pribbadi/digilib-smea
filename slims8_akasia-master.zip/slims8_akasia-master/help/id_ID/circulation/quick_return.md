####Pengembalian Kilat
<hr>
Pengembalian kilat digunakan untuk melakukan pengembalian secara cepat.
Untuk menggunakan fitur ini, cukup memasukkan Item Id / Nomor barcode koleksi. 
