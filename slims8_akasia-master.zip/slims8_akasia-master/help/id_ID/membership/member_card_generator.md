####Member Card
<hr>
Menu ini digunakan untuk mencetak kartu anggota. Cara mencetaknya sama dengan cara mencetak label atau barcode.
Informasi yang ada dalam kartu anggota ini adalah:
- No Anggota,
- Nama,
- Tipe Anggota,
- Barcode,
- Foto (Jika ada) dan
- Identitas perpustakaan.
