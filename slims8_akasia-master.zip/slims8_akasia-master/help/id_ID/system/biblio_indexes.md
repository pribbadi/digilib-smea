### Indexs Biblio
<hr>
Menu ini digunakan untuk melakukan index pada database bibliografi yang adalam SLiMS. Dengan adanya proses index ini maka performa pencarian dalam SLiMS dapat meningkat

Terdapat tiga fungsi pada menu ini:

- Emptying Index untuk mengosongkan hasil index yang sudah ada
- Re-Create Index, untuk membuat ulang index kesemua data bibliografi dalam database
- Update index, untuk melakukan index pada data bibliografi yang belum terindex.

Seting index dapat anda temukan pada file sysconfic.local.inc.php. Jika index menggunakan type index, maka harus dilakukan indexing seperti pada petunjuk di atas.
