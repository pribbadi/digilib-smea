### Setelan hari libur
<hr>
Pada fitur ini anda dapat menentukan hari-hari libur perpustakaan. Pendefinisian hari libur ini akan berpengaruh pada perhitungan hari kerja/buka aktif perpustakaan dan perhitungan denda. Ada dua jenis hari libur yang dapat didefinisikan dalam menu ini, hari libur rutin (Senin s.d. Minggu) dan hari libur khusus (didefinisikan dengan tanggal, bulan dan tahun).
