### Catatan sistem
<hr>
Pada menu ini anda dapat melihat rekaman/log yang terjadi selama SLiMS digunakan. Rekaman yang muncul adalah Time (waktu), Location (lokasi -nama modul-), dan Message (keterangan). Message yang muncul dalam System Logs ini meliputi siapa (User/Administrator), melakukan apa dan dari mana.
Anda juga dapat menyimpan log melalui SAVE LOGS TO FILES. Proses ini akan menyimpan log yang, dan kemudian kita bersihkan layar dengan klik CLEAR LOGS.
